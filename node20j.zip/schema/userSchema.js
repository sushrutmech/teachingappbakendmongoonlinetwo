var user = {
    userId:"",
    userName:"",
    lastName:"",
    email:"",
    password:'',
    userRole:'user',
    userImage:''
}